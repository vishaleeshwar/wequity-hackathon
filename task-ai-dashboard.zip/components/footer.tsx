export function Footer() {
  return (
    <footer className="h-12 bg-[#2a2a30] border-t border-gray-800 px-6 flex items-center justify-between text-xs text-gray-400">
      <div>© 2025 TaskAI. All rights reserved.</div>
      <div className="flex gap-6">
        <button className="hover:text-white">Privacy Policy</button>
        <button className="hover:text-white">Terms of Service</button>
        <button className="hover:text-white">Contact</button>
      </div>
    </footer>
  )
}
