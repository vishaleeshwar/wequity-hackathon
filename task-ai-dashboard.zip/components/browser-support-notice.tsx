"use client"

import { useState, useEffect } from "react"
import { X, Info } from "lucide-react"

export function BrowserSupportNotice() {
  const [isVisible, setIsVisible] = useState(false)
  const [isSpeechSupported, setIsSpeechSupported] = useState(true)
  const [isSecureContext, setIsSecureContext] = useState(true)

  useEffect(() => {
    // Check if we're in a secure context (HTTPS or localhost)
    if (typeof window !== "undefined") {
      setIsSecureContext(window.isSecureContext)
    }

    // Check if the browser supports the Web Speech API
    if (typeof window !== "undefined" && !("SpeechRecognition" in window) && !("webkitSpeechRecognition" in window)) {
      setIsSpeechSupported(false)
      setIsVisible(true)
    }
  }, [])

  if (!isVisible) return null

  // If we're not in a secure context, show a specific message about that
  if (!isSecureContext) {
    return (
      <div className="fixed bottom-4 right-4 bg-yellow-900/80 border border-yellow-700 text-yellow-100 p-4 rounded-lg shadow-lg max-w-xs">
        <div className="flex items-start">
          <div className="flex-1">
            <h3 className="font-medium mb-1 flex items-center gap-1">
              <Info size={16} />
              Secure Connection Required
            </h3>
            <p className="text-sm">
              Voice recognition requires a secure connection (HTTPS). Please access this application via HTTPS to use
              voice features.
            </p>
          </div>
          <button onClick={() => setIsVisible(false)} className="ml-2 p-1 text-yellow-200 hover:text-white">
            <X size={16} />
          </button>
        </div>
      </div>
    )
  }

  // If speech isn't supported, show the browser compatibility message
  if (!isSpeechSupported) {
    return (
      <div className="fixed bottom-4 right-4 bg-yellow-900/80 border border-yellow-700 text-yellow-100 p-4 rounded-lg shadow-lg max-w-xs">
        <div className="flex items-start">
          <div className="flex-1">
            <h3 className="font-medium mb-1 flex items-center gap-1">
              <Info size={16} />
              Voice Assistant Limited
            </h3>
            <p className="text-sm">
              Your browser doesn't support voice recognition. For the best experience, try Chrome, Edge, or Safari.
            </p>
          </div>
          <button onClick={() => setIsVisible(false)} className="ml-2 p-1 text-yellow-200 hover:text-white">
            <X size={16} />
          </button>
        </div>
      </div>
    )
  }

  return null
}
