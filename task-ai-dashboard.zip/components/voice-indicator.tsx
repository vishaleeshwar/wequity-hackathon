"use client"

import { useEffect, useState } from "react"

export function VoiceIndicator() {
  const [levels, setLevels] = useState([0.3, 0.5, 0.7, 0.5, 0.3])

  useEffect(() => {
    const interval = setInterval(() => {
      setLevels((prev) => prev.map(() => Math.random() * 0.7 + 0.3))
    }, 150)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex items-center gap-0.5 h-4">
      {levels.map((level, i) => (
        <div
          key={i}
          className="w-1 bg-blue-500 rounded-full transition-all duration-150 ease-in-out"
          style={{ height: `${level * 16}px` }}
        />
      ))}
    </div>
  )
}
