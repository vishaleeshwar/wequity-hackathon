"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { TaskInput } from "@/components/task-input"
import { QuickActions } from "@/components/quick-actions"
import { RecentlyAsked } from "@/components/recently-asked"
import { ChatInput } from "@/components/chat-input"
import { Footer } from "@/components/footer"
import { BrowserSupportNotice } from "@/components/browser-support-notice"

export function Dashboard() {
  const [userName, setUserName] = useState("Anna")

  return (
    <div className="flex h-screen bg-[#1a1a1a] text-white">
      <Sidebar />
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto bg-[#3a3a3e] p-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8 text-center">
              <h1 className="text-2xl font-semibold mb-2">Hello, {userName}!</h1>
              <p className="text-gray-400 text-sm">What would you like to accomplish today?</p>
            </div>

            <TaskInput />

            <QuickActions />

            <RecentlyAsked />

            <div className="mt-8">
              <ChatInput />
            </div>
          </div>
        </main>
        <Footer />
      </div>
      <BrowserSupportNotice />
    </div>
  )
}
