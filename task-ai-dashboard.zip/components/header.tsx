import { Search, Bell } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function Header() {
  return (
    <header className="h-14 bg-[#1e1e24] border-b border-gray-800 px-4 flex items-center justify-between">
      <div className="flex items-center">
        <div className="font-bold text-blue-500 mr-8">TaskAI</div>
        <nav className="hidden md:flex">
          <button className="px-4 py-1 text-sm font-medium text-white">Dashboard</button>
          <button className="px-4 py-1 text-sm font-medium text-gray-400 hover:text-white">Tasks</button>
          <button className="px-4 py-1 text-sm font-medium text-gray-400 hover:text-white">Analytics</button>
        </nav>
      </div>

      <div className="flex items-center gap-4">
        <button className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white">
          <Search size={18} />
        </button>
        <button className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white">
          <Bell size={18} />
        </button>
        <Avatar className="h-8 w-8">
          <AvatarImage src="/placeholder.svg?height=32&width=32" />
          <AvatarFallback>A</AvatarFallback>
        </Avatar>
      </div>
    </header>
  )
}
