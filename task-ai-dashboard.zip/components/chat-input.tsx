"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Send, Mic, MicOff, AlertCircle } from "lucide-react"
import { VoiceIndicator } from "./voice-indicator"

// Define SpeechRecognition type to avoid Typescript errors
declare global {
  interface Window {
    SpeechRecognition: any
    webkitSpeechRecognition: any
  }
}

export function ChatInput() {
  const [input, setInput] = useState("")
  const [isListening, setIsListening] = useState(false)
  const [isSpeechSupported, setIsSpeechSupported] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const recognitionRef = useRef<any>(null)
  const retryTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Initialize speech recognition
  const initializeSpeechRecognition = () => {
    // Clear any existing recognition instance
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop()
      } catch (e) {
        // Ignore errors when stopping
      }
      recognitionRef.current = null
    }

    // Check if the browser supports the Web Speech API
    if (typeof window !== "undefined") {
      const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition
      if (!SpeechRecognitionAPI) {
        setIsSpeechSupported(false)
        setError("Your browser doesn't support speech recognition")
        return false
      }

      try {
        recognitionRef.current = new SpeechRecognitionAPI()
        recognitionRef.current.continuous = false // Changed to false to avoid network overload
        recognitionRef.current.interimResults = true
        recognitionRef.current.lang = "en-US"

        recognitionRef.current.onresult = (event: any) => {
          const transcript = Array.from(event.results)
            .map((result: any) => result[0])
            .map((result: any) => result.transcript)
            .join("")

          setInput(transcript)
          setError(null)
        }

        recognitionRef.current.onerror = (event: any) => {
          console.warn("Speech recognition error", event.error)

          if (event.error === "network") {
            setError("Network error. Check your internet connection.")
            // Stop listening on network error
            if (recognitionRef.current) {
              try {
                recognitionRef.current.stop()
              } catch (e) {
                // Ignore errors when stopping
              }
            }
            setIsListening(false)
          } else if (event.error === "no-speech") {
            // This is common and not a critical error
            setError("No speech detected. Please try again.")
          } else {
            setError(`Error: ${event.error}`)
          }
        }

        recognitionRef.current.onend = () => {
          setIsListening(false)
        }

        return true
      } catch (error) {
        console.error("Error initializing speech recognition:", error)
        setIsSpeechSupported(false)
        setError("Failed to initialize speech recognition")
        return false
      }
    }
    return false
  }

  useEffect(() => {
    const isInitialized = initializeSpeechRecognition()

    return () => {
      // Clean up
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop()
        } catch (e) {
          // Ignore errors when stopping
        }
      }

      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current)
      }
    }
  }, [])

  const toggleListening = () => {
    // Clear any existing error
    setError(null)

    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop()
        } catch (e) {
          console.error("Error stopping recognition:", e)
        }
      }
      setIsListening(false)
    } else {
      // Re-initialize recognition before starting
      if (initializeSpeechRecognition()) {
        try {
          recognitionRef.current.start()
          setIsListening(true)
        } catch (e) {
          console.error("Error starting recognition:", e)
          setError("Failed to start listening. Please try again.")
        }
      }
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim()) {
      // Here you would handle sending the message
      console.log("Sending message:", input)
      setInput("")
    }
  }

  return (
    <div className="space-y-2">
      {error && (
        <div className="flex items-center gap-2 text-yellow-400 text-sm p-2 bg-yellow-950/50 rounded-md">
          <AlertCircle size={16} />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="flex gap-2">
        <div
          className={`flex-1 bg-[#2a2a30] rounded-lg px-4 py-2 flex items-center ${isListening ? "ring-2 ring-blue-500" : ""}`}
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isListening ? "Listening..." : "Ask anything..."}
            className="bg-transparent border-none outline-none w-full text-sm"
          />
          {isListening && <VoiceIndicator />}
          {isSpeechSupported && (
            <button
              type="button"
              onClick={toggleListening}
              className={`ml-2 p-1.5 rounded-full ${isListening ? "bg-blue-600 text-white" : "text-gray-400 hover:text-white"}`}
            >
              {isListening ? <MicOff size={16} /> : <Mic size={16} />}
            </button>
          )}
        </div>
        <button
          type="submit"
          disabled={!input.trim()}
          className="bg-blue-600 text-white rounded-lg px-4 py-2 text-sm font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Send size={16} />
          Send
        </button>
      </form>
    </div>
  )
}
